#ifndef Analysis_hh
#define Analysis_hh

#include "G4VAnalysisManager.hh"

#endif
